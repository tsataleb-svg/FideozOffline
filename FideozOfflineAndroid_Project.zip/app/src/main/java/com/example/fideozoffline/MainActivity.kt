package com.example.fideozoffline

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

data class LocalVideo(val uri: Uri, val title: String)

class MainActivity : AppCompatActivity() {
    private lateinit var pager: ViewPager2
    private lateinit var empty: LinearLayout
    private val videos = mutableListOf<LocalVideo>()
    private var activePlayer: ExoPlayer? = null

    private val importVideo = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                catch (_: Exception) {}
                if (videos.none { it.uri == uri }) videos.add(LocalVideo(uri, uri.lastPathSegment ?: "فيديو"))
            }
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        buildUi()
        loadDeviceVideos()
        refresh()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF08090D.toInt())
        }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
            setPadding(18, 12, 18, 12)
        }
        val title = TextView(this).apply {
            text = "فيديوز"; textSize = 23f; setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        top.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val import = Button(this).apply {
            text = "＋ استيراد"
            setOnClickListener { importVideo.launch(arrayOf("video/*")) }
        }
        top.addView(import)
        root.addView(top)

        pager = ViewPager2(this).apply {
            orientation = ViewPager2.ORIENTATION_VERTICAL
            offscreenPageLimit = 1
            setBackgroundColor(0xFF101116.toInt())
        }
        root.addView(pager, LinearLayout.LayoutParams(-1, 0, 1f))

        empty = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 30, 28, 30)
            val msg = TextView(this@MainActivity).apply {
                text = "مكتبة الفيديوهات المحلية\\n\\nاستورد فيديوهاتك من الهاتف لمشاهدتها بالتمرير العمودي. يعمل التطبيق دون إنترنت."
                textSize = 18f; gravity = Gravity.CENTER; setTextColor(0xFFE6E6EA.toInt())
            }
            addView(msg)
            addView(Button(this@MainActivity).apply {
                text = "اختيار فيديوهات"
                setOnClickListener { importVideo.launch(arrayOf("video/*")) }
            })
        }
        root.addView(empty, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = TextView(this).apply {
            text = "الرئيسية       فيديوهاتي       الملف الشخصي"
            textSize = 14f; gravity = Gravity.CENTER; setTextColor(0xFFB9BAC4.toInt())
            setPadding(8, 15, 8, 18)
            setOnClickListener {
                Toast.makeText(this@MainActivity, "الملف الشخصي محلي — لا يحتاج إلى حساب", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun loadDeviceVideos() {
        val projection = arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        try {
            contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, sort
            )?.use { c: Cursor ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                while (c.moveToNext()) {
                    val uri = Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(idCol).toString())
                    if (videos.none { it.uri == uri }) videos.add(LocalVideo(uri, c.getString(nameCol) ?: "فيديو"))
                }
            }
        } catch (_: Exception) { }
    }

    private fun refresh() {
        pager.visibility = if (videos.isEmpty()) View.GONE else View.VISIBLE
        empty.visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
        pager.adapter = VideoAdapter()
        pager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) { playAt(position) }
        })
        if (videos.isNotEmpty()) pager.post { playAt(0) }
    }

    private fun playAt(position: Int) {
        activePlayer?.release()
        if (position !in videos.indices) return
        val player = ExoPlayer.Builder(this).build()
        activePlayer = player
        player.setMediaItem(MediaItem.fromUri(videos[position].uri))
        player.repeatMode = Player.REPEAT_MODE_ONE
        player.prepare()
        player.playWhenReady = true
        pager.findViewWithTag<PlayerView>("player_$position")?.player = player
    }

    override fun onPause() {
        activePlayer?.pause()
        super.onPause()
    }

    override fun onDestroy() {
        activePlayer?.release()
        activePlayer = null
        super.onDestroy()
    }

    private inner class VideoAdapter : androidx.recyclerview.widget.RecyclerView.Adapter<VideoHolder>() {
        override fun getItemCount() = videos.size
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VideoHolder {
            val frame = FrameLayout(this@MainActivity).apply { setBackgroundColor(0xFF08090D.toInt()) }
            val pv = PlayerView(this@MainActivity).apply {
                useController = true
                setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING)
                layoutParams = FrameLayout.LayoutParams(-1, -1)
            }
            frame.addView(pv)
            val label = TextView(this@MainActivity).apply {
                setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
                setPadding(18, 18, 18, 34)
                setBackgroundColor(0x55000000)
            }
            frame.addView(label, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            return VideoHolder(frame, pv, label)
        }
        override fun onBindViewHolder(holder: VideoHolder, position: Int) {
            holder.label.text = "▶  ${videos[position].title}"
            holder.playerView.tag = "player_$position"
            if (position == pager.currentItem) holder.playerView.player = activePlayer
        }
        override fun onViewRecycled(holder: VideoHolder) {
            holder.playerView.player = null
            super.onViewRecycled(holder)
        }
    }

    private class VideoHolder(view: View, val playerView: PlayerView, val label: TextView) :
        androidx.recyclerview.widget.RecyclerView.ViewHolder(view)
}
